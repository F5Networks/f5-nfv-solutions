#!/bin/bash
echo '******Overriding Default Configuration******' > /var/log/cloud/openstack/cloud_config.log

#vars - TODO - pass it as arguments to script
disable1Nic="${1}"
admin_password="${2}"
root_password="${3}"

if [ "$disable1Nic" == "True" ]; then
  /usr/bin/setdb provision.1nicautoconfig disable
fi
/usr/bin/passwd admin "$admin_password" >/dev/null 2>&1
/usr/bin/passwd root "$root_password" >/dev/null 2>&1

mkdir -m 0755 -p /config/cloud/openstack
mkdir -m 0755 -p /mnt/creds
cd /config/cloud/openstack
echo "$admin_password" >> /mnt/creds/.adminPwd

echo '******Finished Overriding Default Configuration******' > /var/log/cloud/openstack/cloud_config.log

