#!/bin/bash

function wait_cloud_libs_install() {
    while true; do echo 'wait-cloudLibsInstall: Waiting for cloud libs install to complete' >> /var/log/cloud/openstack/cloud_config.log
        if [ -f /config/cloud/openstack/cloudLibsReady ]; then
            break
        else
            sleep 10
        fi
    done
}

function main() {
    wait_cloud_libs_install
}

main
