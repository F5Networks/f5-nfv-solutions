#!/bin/bash

ntp=${1}
tz=${2}

echo '*****NTP_CONFIG STARTING******' >> /var/log/cloud/openstack/cloud_config.log

f5-rest-node /config/cloud/openstack/node_modules/@f5devcentral/f5-cloud-libs/scripts/onboard.js \
  --host localhost --ntp "${ntp}" --tz "${tz}" --user admin --password-url file:///config/cloud/openstack/.adminPwd --password-encrypted
bigstart stop ntpd
ntpdate -s ${ntp}
bigstart start ntpd

echo '*****NTP_CONFIG FINISHED******' >> /var/log/cloud/openstack/cloud_config.log
 
